class EntityStats{

  // Stats for all entities in the game
	private int health;
  private int attackDamage;
  private int abilityPower;
  private int armor;
  private int magicResist;
  private double attackSpeed;
  private int cdr;
  private int critchance;
  private int movementSpeed;
     
     // Constructor
  public EntityStats(int health, int attackDamage, int abilityPower, int armor, int magicResist, double attackSpeed, int cdr,int critchance, int movementSpeed) {
    this.health = health;
    this.attackDamage = attackDamage;
    this.abilityPower = abilityPower;
    this.armor = armor;
    this.magicResist = magicResist;
    this.attackSpeed = attackSpeed;
    this.cdr = cdr;
    this.critchance = critchance;
    this.movementSpeed = movementSpeed;
  }
    
  // Getters and Setters
  public int getHP() {
    return health;
  }

  public void setHP(int n) {
    health = n;
  }

  public int getAD() {
    return attackDamage;
  }

  public void setAD(int n) {
    attackDamage = n;
  }

  public int getAP() {
    return abilityPower;
  }

  public void setAP(int n) {
    abilityPower = n;
  }

  public int getAR() {
    return armor;
  }

  public void setAR(int n) {
    armor = n;
  }

  public int getMR() {
	  return magicResist;
  }

  public void setMR(int n) {
    magicResist = n;
  }

  public int getCdr() {
    return cdr;
  }

  public void setCdr(int n) {
    cdr = n;
  }

  public double getAS() {
    return attackSpeed;
  }

  public void setAS(double n) {
    attackSpeed = n;
  }

  public int getCrit() {
    return critchance;
  }

  public void setCrit(int n) {
    critchance = n;
  }

  public int getMS() {
    return movementSpeed;
  }

  public void setMS(int n) {
    movementSpeed = n;
  }

}